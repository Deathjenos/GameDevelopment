﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WOverview : MonoBehaviour {

	private int lives = 0;
	private string TimeText = "";

	public GameObject TimeTextObject;
	private Text TTO;

	public GameObject liveText;
	private Text LT;


	//Initialization
	private void Awake () {
		TTO = TimeTextObject.GetComponent<Text> ();
		LT = liveText.GetComponent<Text> ();
		ExtractPackage ();
		SetStatsOnScreen ();
	}
	

	//Extract information from the StatsPackage
	private void ExtractPackage(){
		GameObject SP = GameObject.FindGameObjectWithTag ("Package");
		StatsPackage SPCode = SP.GetComponent<StatsPackage> ();
		lives = SPCode.lives;
		TimeText = SPCode.TimeText;
		Destroy (SP);
	}


	//Set stats onScreen
	private void SetStatsOnScreen(){
		TTO.text = "Time: " + TimeText;
		LT.text = "Lives left: " + lives.ToString ();
	}

}//CLASS
