﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StatsPackage : MonoBehaviour {

	public string TimeText = "";
	public int lives = 0;
	public int cells = 0;


	//Initialization
	private void Awake() {
		DontDestroyOnLoad (gameObject);
	}

}//CLASS
