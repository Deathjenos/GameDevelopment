﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EscapeToQuitScript : MonoBehaviour {
	
	// Update is called once per frame
	private void Update () {
		Application.Quit ();
	}
		
}//CLASS
