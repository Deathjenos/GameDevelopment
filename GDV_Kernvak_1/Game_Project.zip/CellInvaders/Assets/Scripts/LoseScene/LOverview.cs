﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LOverview : MonoBehaviour {

	private int cells = 0;
	private string TimeText = "";

	public GameObject TimeTextObject;
	private Text TTO;

	public GameObject CellText;
	private Text CT;


	//Initialization
	private void Awake () {
		TTO = TimeTextObject.GetComponent<Text> ();
		CT = CellText.GetComponent<Text> ();
		ExtractPackage ();
		SetStatsOnScreen ();
	}


	//Extract information from the StatsPackage
	private void ExtractPackage(){
		GameObject SP = GameObject.FindGameObjectWithTag ("Package");
		StatsPackage SPCode = SP.GetComponent<StatsPackage> ();
		cells = SPCode.cells;
		TimeText = SPCode.TimeText;
		Destroy (SP);
	}


	//Set stats onScreen
	private void SetStatsOnScreen(){
		TTO.text = "Time: " + TimeText;
		CT.text = "Cells left: " + cells.ToString ();
	}

}//CLASS
