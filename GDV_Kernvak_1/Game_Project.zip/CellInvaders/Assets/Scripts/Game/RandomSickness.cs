﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomSickness : MonoBehaviour {

	public float minRandom = 5f;
	public float maxRandom = 20f;

	private float sickTime = 0f;

	public GameObject Sickness;


	//Initialize
	private void Awake () {
		RandomSickTime ();
		StartCoroutine (SickSpawn ());
	}


	//Random SickTime
	private void RandomSickTime(){
		sickTime = Random.Range (minRandom, maxRandom);
	}


	//Wait for Sickness spawn
	private IEnumerator SickSpawn(){
		yield return new WaitForSeconds (sickTime);
		Instantiate (Sickness, transform.position, Quaternion.identity);
		RandomSickTime ();
		StartCoroutine (SickSpawn ());
	}

}//CLASS
