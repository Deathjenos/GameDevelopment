﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellSplitting : MonoBehaviour {

	public GameObject ParentCell;
	public GameObject ChildCell1;
	private CellSplitting C1;
	public GameObject ChildCell2;
	private CellSplitting C2;

	public float splitTime = 1f;

	public bool hasParent = true;
	public bool hasChildren = true;

	public bool inSplitTime1 = false;
	public bool inSplitTime2 = false;

	public bool FrozenCell = false;

	private SpriteRenderer SR;
	public Sprite CellNormal;
	public Sprite CellFrozen;

	public int activeChildren = 2;
	public int activeFamily = 0;


	//Initialization
	private void Awake () {
		//Components
		SR = GetComponent<SpriteRenderer>();
		C1 = ChildCell1.GetComponent<CellSplitting> ();
		C2 = ChildCell2.GetComponent<CellSplitting> ();

		//Security
		if (!hasParent) {
			ParentCell = gameObject;
		}
		if (!hasChildren) {
			ChildCell1 = gameObject;
			ChildCell2 = gameObject;
		}

		//Initialization
		if (hasParent) {
			ParentCell = transform.parent.gameObject;
		}
		if (hasChildren) {
			ChildCell1 = transform.GetChild (0).gameObject;
			ChildCell2 = transform.GetChild (1).gameObject;
		}
	}


	// Update is called once per frame
	private void Update () {
		if (hasChildren) {
			CheckActive ();
			CheckFrozen ();
		}
	}


	//Checks if Cell1 or Cell2 has been destroyed
	private void CheckActive(){
		if (!ChildCell1.activeSelf && !inSplitTime1) {
			StartCoroutine (SplitTime (1));
			inSplitTime1 = true;
		}
		if (!ChildCell2.activeSelf && !inSplitTime2) {
			StartCoroutine (SplitTime (2));
			inSplitTime2 = true;
		}

		//Calculate amount of cells active
		if (ChildCell1.activeSelf && ChildCell2.activeSelf) {
			activeChildren = 2;
		} 
		else if (ChildCell1.activeSelf) {
			activeChildren = 1;
		} 
		else if (ChildCell1.activeSelf) {
			activeChildren = 1;
		} 
		else {
			activeChildren = 0;
		}
		activeFamily = activeChildren;
		if (ChildCell1.activeSelf) {
			activeFamily += C1.activeFamily;
		}
		if (ChildCell2.activeSelf) {
			activeFamily += C2.activeFamily;
		}
		if (!hasParent) {
			activeFamily++;
		}
	}
		

	//Respawn the cell after a period of time
	private IEnumerator SplitTime(int WhichCell){
		yield return new WaitForSeconds (splitTime);
		if (gameObject.activeSelf) {
			switch (WhichCell) {
			case 1:
				ChildCell1.SetActive (true);
				inSplitTime1 = false;
				break;
			case 2:
				ChildCell2.SetActive (true);
				inSplitTime2 = false;
				break;
			}	
		} 
	}


	private void CheckFrozen(){
		if (!ChildCell1.activeSelf && !ChildCell2.activeSelf) {
			SR.sprite = CellNormal;
			FrozenCell = false;
		} 
		else {
			SR.sprite = CellFrozen;
			FrozenCell = true;
		}
	}
		
}//CLASS
