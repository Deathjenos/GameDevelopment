﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellMovement : MonoBehaviour {

	public float speedPerTick = 5f;
	public float tickInterval = 1f;

	public float boundaryLeft = -3f;
	public float boundaryRight = 3f;

	private float direction = 1;


	// Use this for initialization
	private void Start () {
		StartCoroutine (Ticker ());
	}


	//Ticking timer
	private IEnumerator Ticker(){
		yield return new WaitForSeconds (tickInterval);
		MoveCells ();
	}


	//Move the cells
	private void MoveCells(){
		Vector2 Pos = transform.position;

		//Move Right
		if(direction == 1){
			if (Pos.x >= boundaryRight) {
				direction = -1;
				transform.position = new Vector2 (Pos.x - speedPerTick, Pos.y);
			} 
			else {
				transform.position = new Vector2 (Pos.x + speedPerTick, Pos.y);
			}
			StartCoroutine (Ticker ());
		}

		//Move Left
		else if(direction == -1){
			if (Pos.x <= boundaryLeft) {
				direction = 1;
				transform.position = new Vector2 (Pos.x + speedPerTick, Pos.y);
			} 
			else {
				transform.position = new Vector2 (Pos.x - speedPerTick, Pos.y);
			}
			StartCoroutine (Ticker ());
		}
		else{
			StartCoroutine (Ticker ());
		}
	}

}
