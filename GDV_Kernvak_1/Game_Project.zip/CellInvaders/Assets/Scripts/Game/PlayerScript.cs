﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {

	public float speed = 5f;

	public GameObject WhiteCellObject;


	// Update is called once per frame
	private void Update () {
		PlayerMove ();
		PlayerShoot ();
	}


	//Player Movement
	private void PlayerMove(){
		float X = Input.GetAxisRaw ("Horizontal") * speed * Time.deltaTime;

		if (X < 0 && transform.position.x >= -8.2f) {
			transform.position = new Vector2 (transform.position.x + X, transform.position.y);
		}
		if (X > 0 && transform.position.x <= 8.2f) {
			transform.position = new Vector2 (transform.position.x + X, transform.position.y);
		}
			
	}


	//Player Shooting
	private void PlayerShoot(){
		if (Input.GetKeyDown (KeyCode.Space)) {
			Instantiate (WhiteCellObject, transform.position, Quaternion.identity);
		}
	}

}//CLASS
