﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WhiteCell : MonoBehaviour {

	public float speed = 5f;

	public float maxHeight = 8f;


	// Update is called once per frame
	private void Update () {
		MoveUp ();
	}


	private void MoveUp(){
		float Y = transform.position.y + (speed * Time.deltaTime);
		transform.position = new Vector2 (transform.position.x, Y);

		if (transform.position.y >= maxHeight) {
			Destroy (gameObject);
		}
	}


	public void OnTriggerEnter2D(Collider2D Target){
		if (Target.gameObject.tag == "Cell") {
			Destroy (gameObject);
			CellSplitting CellScript = Target.gameObject.GetComponent<CellSplitting> ();
			if (!CellScript.FrozenCell) {
				Target.gameObject.SetActive (false);
				CellScript.inSplitTime1 = false;
				CellScript.inSplitTime2 = false;
			}
		}
	}
}
