﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour {

	public int time = 0;
	public int Hour = 0;
	public int Minutes = 0;
	public int Seconds = 0;
	public GameObject timeText;
	private Text TT;
	private GameObject GO;
	private GOverview GOCode;
	private string TimeText;


	//Initialization
	private void Awake () {
		TT = timeText.GetComponent<Text> ();
		GO = GameObject.Find ("GameOverview");
		GOCode = GO.GetComponent<GOverview> ();
		StartCoroutine (TimeUp ());
	}


	// Update is called once per frame
	private void Update () {
		Hour = (time / 3600);
		Minutes = (time / 60) - (Hour * 60); 
		Seconds = time % 60;
		TimeText = Hour + " : " + Minutes + " : " + Seconds;
		TT.text = TimeText;
		GOCode.TimeText = TimeText;
	}


	//Up time
	private IEnumerator TimeUp(){
		yield return new WaitForSeconds (1f);
		time++;
		StartCoroutine (TimeUp ());
	}

}//CLASS
