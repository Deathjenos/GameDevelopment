﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GOverview : MonoBehaviour {

	private GameObject CCO;
	public GameObject Life1;
	public GameObject Life2;
	public GameObject Life3;
	public GameObject CellText;
	private Text CT;

	public int lives = 3;
	private int cells = 49;

	public string LoseScene = "LoseScene";
	public string WinScene = "WinScene";
	public GameObject SP;

	public string TimeText;


	//Initialization
	private void Awake () {
		CCO = GameObject.Find ("CellCollection");
		CT = CellText.GetComponent<Text> ();
	}


	// Update is called once per frame
	private void Update () {
		CheckLives ();
		CheckCells ();
	}


	//Checks and updates the current amount of lives, also checks the lose condition
	private void CheckLives(){
		//Updates Lives UI
		if (lives == 3) {
			Life1.SetActive (true);
			Life2.SetActive (true);
			Life3.SetActive (true);
		} 
		else if (lives == 2) {
			Life1.SetActive (true);
			Life2.SetActive (true);
			Life3.SetActive (false);
		} 
		else if (lives == 1) {
			Life1.SetActive (true);
			Life2.SetActive (false);
			Life3.SetActive (false);
		} 
		else if (lives == 0) {
			Life1.SetActive (false);
			Life2.SetActive (false);
			Life3.SetActive (false);
		} 
		else {
			lives = 0;
		}

		//Lose Condition
		if (lives <= 0) {
			GameObject SPObject = GameObject.Instantiate (SP, transform.position, Quaternion.identity);
			StatsPackage SPCode = SPObject.GetComponent<StatsPackage> ();
			SPCode.TimeText = TimeText;
			SPCode.lives = lives;
			SPCode.cells = cells;
			SceneManager.LoadScene (LoseScene);
		}
	}


	//Checks and updates the current amount of cells, also checks the win condition
	private void CheckCells(){
		int Corecells = CCO.transform.childCount;
		cells = 0;
		for (int i = 0; i < Corecells; i++) {
			GameObject currentCell = CCO.transform.GetChild (i).gameObject;
			CellSplitting currentCS = currentCell.GetComponent<CellSplitting> ();
			if (currentCell.activeSelf) {
				cells += currentCS.activeFamily;
			}
		}
		CT.text = cells.ToString ();

		//Win Condition
		if (cells == 0) {
			GameObject SPObject = GameObject.Instantiate (SP, transform.position, Quaternion.identity);
			StatsPackage SPCode = SPObject.GetComponent<StatsPackage> ();
			SPCode.TimeText = TimeText;
			SPCode.lives = lives;
			SPCode.cells = cells;
			SceneManager.LoadScene (WinScene);
		}
	}

}//CLASS
