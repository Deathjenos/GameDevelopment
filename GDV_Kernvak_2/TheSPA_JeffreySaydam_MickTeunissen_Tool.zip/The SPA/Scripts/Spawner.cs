﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {

    //Spawner Settings
    public GameObject ObjectToSpawn;        //GameObject to spawn
    public float SpawnTime = 1f;            //Waittime until spawn
    ///Begin amount of objects
    public bool HasStartAmount = false;
    public int StartAmount = 1;
    ///Spawn Range
    public Vector3 MinSpawnPosition = new Vector3(-1, -1, -1);
    public Vector3 MaxSpawnPosition = new Vector3(1, 1, 1);
    /// Spawn Rotation
    public bool HasRandomRotation = false;
    public bool RandomX = false;
    public float maximumRotationDegreeX = 360f;
    public bool RandomY = false;
    public float maximumRotationDegreeY = 360f;
    public bool RandomZ = false;
    public float maximumRotationDegreeZ = 360f;

    ///Collider Range
    public bool HasSpawnArea = false;
    public GameObject SpawnArea;
    ///Maximum Objects
    public bool MaximumObject = true;       //Is there a limit on the maximum of objects allowed in the level?
    public int MaxObjectsAllowed = 1;       //Maximal Amount of Objects allowed in the level

    //Spawner Script Variables
    private Vector3 SpawnPosition;
    private Vector3 SpawnRotation;
    private List<GameObject> SpawnObjectList = new List<GameObject>();
    private bool MaySpawn = true;

	//When the game starts
	void Start () {
        //Spawn Area
        if (HasSpawnArea) { SetSpawnAreaVariables(); }
        //Start Spawn
        if (HasStartAmount) { StartSpawn(); }   
        //Continuous Spawning
		StartCoroutine (SpawnObjectTimer ());
	}
	

	// Update is called once per frame
	void Update () {
        if (MaximumObject)
        {
            DeleteOverflow();
        }
	}


    //Set Spawn Area Variables
    private void SetSpawnAreaVariables()
    {
        Collider AreaCollider = SpawnArea.GetComponent<Collider>();
        if(AreaCollider != null)
        {
            MinSpawnPosition = AreaCollider.bounds.min;
            MaxSpawnPosition = AreaCollider.bounds.max;
        }
    }


    //Start Spawn
    private void StartSpawn()
    {
        //Max Objects Security
        if (MaximumObject)
        {
            if(StartAmount > MaxObjectsAllowed)
            {
                StartAmount = MaxObjectsAllowed;
            }
        }

        //Begin Spawning
        for(int i = 0; i < StartAmount; i++)
        {
            RandomizeSpawnPosition();
            SpawnObject();
        }
    }



    //Wait and Spawn Object
	private IEnumerator SpawnObjectTimer(){
        if (MaySpawn)
        {
            RandomizeSpawnPosition();
            SpawnObject();
        }

        //Clean-up
        CleanUpSpawnObjectList();

		yield return new WaitForSeconds (SpawnTime);
		StartCoroutine (SpawnObjectTimer());
	}


    //Set Random Spawn Position
    private void RandomizeSpawnPosition()
    {
        //Randomized Position
        float randomX = Random.Range(MinSpawnPosition.x, MaxSpawnPosition.x);
        float randomY = Random.Range(MinSpawnPosition.y, MaxSpawnPosition.y);
        float randomZ = Random.Range(MinSpawnPosition.z, MaxSpawnPosition.z);

        //Set Spawn Position
        SpawnPosition = new Vector3(randomX, randomY, randomZ);
    }


    //Spawn Object
    private void SpawnObject()
    {
        GameObject GObject = Instantiate(ObjectToSpawn, SpawnPosition, Quaternion.identity);
        if (HasRandomRotation) {
            SetSpawnRotation();
            GObject.transform.localEulerAngles = SpawnRotation;
        }
        SpawnObjectList.Add(GObject);
    }


    //Check if MaxObjects has been exceeded
	private void DeleteOverflow(){
        if(SpawnObjectList.Count < MaxObjectsAllowed)
        {
            MaySpawn = true;
        }
        else
        {
            MaySpawn = false;
        }
	}


    //Clean-up SpawnObjectList
    private void CleanUpSpawnObjectList()
    {
        SpawnObjectList.RemoveAll(item => item == null);
    }


    //Set Spawn Rotation
    private void SetSpawnRotation() {
        if (HasRandomRotation) {
            Vector3 CurrentRotation = new Vector3();
            
            //Set X Rotation
            if (RandomX) {
                CurrentRotation.x = Random.Range(0, maximumRotationDegreeX);
            } else {
                CurrentRotation.x = ObjectToSpawn.transform.localEulerAngles.x;
            }

            //Set Y Rotation
            if (RandomY) {
                CurrentRotation.y = Random.Range(0, maximumRotationDegreeY);
            } else {
                CurrentRotation.y = ObjectToSpawn.transform.localEulerAngles.y;
            }

            //Set Z Rotation
            if (RandomZ) {
                CurrentRotation.z = Random.Range(0, maximumRotationDegreeZ);
            } else {
                CurrentRotation.z = ObjectToSpawn.transform.localEulerAngles.z;
            }

            SpawnRotation = CurrentRotation;
        } 
        else {
            SpawnRotation = ObjectToSpawn.transform.localEulerAngles;
        }
    }


}//CLASS
