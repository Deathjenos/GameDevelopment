﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System;

//Spawner Struct for the tool
public struct SpawnObject {
    public Spawner SP;

    public SpawnObject(Spawner SP) {
        this.SP = SP;
    }

}//STRUCT

//The Tool
public class TheSPA : EditorWindow {

    //GUI Skins and Styles
    private GUISkin SPA_SKIN = null;
    private Texture tex = null;

    //Spawner List
    public List<SpawnObject> SpawnerList = new List<SpawnObject>();
    //Spawner Tool: bool Fold List
    public List<bool> FoldList = new List<bool>();

    //Scroll Position
    Vector2 ScrolPos = new Vector2(0, 0);

    //Tool under Window > The SPA
    [MenuItem("Window/The SPA (Spawn Tool)")]

    //Start
    public static void ShowWindow() {
        EditorWindow.GetWindow<TheSPA>("Tool");
    }

    //Show on UI
    void OnGUI() {
        //Set skin
        SetGUIskin();

        //Background
        GUI.Box(new Rect(0f, 0f, Screen.width, Screen.height), "");

        //Scroll begin
        ScrolPos = EditorGUILayout.BeginScrollView(ScrolPos, false, true);

        //HeaderIcon
        SetTex();

        //Show Spawners
        if (SpawnerList != null) {
            for (int i = 0; i < SpawnerList.Count; i++){
                if (SpawnerList[i].SP != null) {
                    SpawnerOnGUI(SpawnerList[i], i);
                }
            }
        }

        //Add Spawner Button
        if (GUILayout.Button("Add SPAwner")) {
            CreateSpawner();
            Debug.Log("Add Spawner Button: Pressed");
        }
        //Scroll end
        EditorGUILayout.EndScrollView();

        //Check Hierarchy Spawners with Tool Spawners
        GetSpawnersInHierarchy();
        ClearNullSpawners();
    }


    //Show Spawner
    void SpawnerOnGUI(SpawnObject SPO, int i) {
        //Get Spawner Script
        Spawner SP = SPO.SP;
        //Set Spawner on GUI
        FoldList[i] = EditorGUILayout.Foldout(FoldList[i], SP.name, true);
        //If unfold show...
        if (FoldList[i]) {
            EditorGUI.indentLevel++;

            //Show SP Variables
            EditorGUILayout.LabelField("Object To Spawn");
            SP.ObjectToSpawn = (GameObject)EditorGUILayout.ObjectField(SP.ObjectToSpawn, typeof(GameObject), true);
            EditorGUILayout.LabelField("Spawntime Between Objects");
            SP.SpawnTime = EditorGUILayout.FloatField(SP.SpawnTime);
            ///Begin amount of objects
            SP.HasStartAmount = EditorGUILayout.BeginToggleGroup("Has a begin amount of objects", SP.HasStartAmount); EditorGUILayout.EndToggleGroup();
            if (SP.HasStartAmount)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.LabelField("Begin amount of objects");
                SP.StartAmount = EditorGUILayout.IntField(SP.StartAmount);
                EditorGUI.indentLevel--;
            }
            ///Spawn Range
            SP.HasSpawnArea = EditorGUILayout.BeginToggleGroup("Has a Collider Spawn Area", SP.HasSpawnArea); EditorGUILayout.EndToggleGroup();
            if (SP.HasSpawnArea)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.LabelField("Spawn Area Object with Collider");
                SP.SpawnArea = (GameObject)EditorGUILayout.ObjectField(SP.SpawnArea, typeof(GameObject), true);
                EditorGUI.indentLevel--;
            }
            else
            {
                SP.MinSpawnPosition = EditorGUILayout.Vector3Field("Minimal Spawn Position", SP.MinSpawnPosition);
                SP.MaxSpawnPosition = EditorGUILayout.Vector3Field("Maximal Spawn Position", SP.MaxSpawnPosition);
            }
            /// Spawn Rotation
            SP.HasRandomRotation = EditorGUILayout.BeginToggleGroup("Has a random rotation", SP.HasRandomRotation); EditorGUILayout.EndToggleGroup();
            if (SP.HasRandomRotation) {
                EditorGUI.indentLevel++;
                SP.RandomX = EditorGUILayout.BeginToggleGroup("Randomize X-axis", SP.RandomX); EditorGUILayout.EndToggleGroup();
                if (SP.RandomX) {
                    EditorGUI.indentLevel++;
                    EditorGUILayout.LabelField("Maximum rotation X-axis");
                    SP.maximumRotationDegreeX = EditorGUILayout.FloatField(SP.maximumRotationDegreeX);
                    EditorGUI.indentLevel--;
                }
                SP.RandomY = EditorGUILayout.BeginToggleGroup("Randomize Y-axis", SP.RandomY); EditorGUILayout.EndToggleGroup();
                if (SP.RandomY) {
                    EditorGUI.indentLevel++;
                    EditorGUILayout.LabelField("Maximum rotation Y-axis");
                    SP.maximumRotationDegreeY = EditorGUILayout.FloatField(SP.maximumRotationDegreeY);
                    EditorGUI.indentLevel--;
                }
                SP.RandomZ = EditorGUILayout.BeginToggleGroup("Randomize Z-axis", SP.RandomZ); EditorGUILayout.EndToggleGroup();
                if (SP.RandomZ) {
                    EditorGUI.indentLevel++;
                    EditorGUILayout.LabelField("Maximum rotation Z-axis");
                    SP.maximumRotationDegreeZ = EditorGUILayout.FloatField(SP.maximumRotationDegreeZ);
                    EditorGUI.indentLevel--;
                }
                EditorGUI.indentLevel--;
            }
            ///Maximum Objects
            SP.MaximumObject = EditorGUILayout.BeginToggleGroup("Has Maximum Object Limit", SP.MaximumObject); EditorGUILayout.EndToggleGroup();
            if (SP.MaximumObject)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.LabelField("Max amount of objects allowed in the world");
                SP.MaxObjectsAllowed = EditorGUILayout.IntField(SP.MaxObjectsAllowed);
                EditorGUI.indentLevel--;
            }

            //Save Preset
            float rememberWidth3 = GUI.skin.button.fixedWidth;
            GUI.skin.button.fixedWidth = 200f;
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("SavePreset")) {

                SP.SaveToolPreset();
                Debug.Log("Preset Saved");

            }
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUI.skin.button.fixedWidth = rememberWidth3;
            EditorGUI.indentLevel--;

            //Load Preset
            float rememberWidth2 = GUI.skin.button.fixedWidth;
            GUI.skin.button.fixedWidth = 200f;
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("LoadPreset")) {

                SP.LoadToolPreset();
                Debug.Log("Preset Loaded");
            }
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUI.skin.button.fixedWidth = rememberWidth2;
            EditorGUI.indentLevel--;


            //Delete this Spawner
            float rememberWidth = GUI.skin.button.fixedWidth;
            GUI.skin.button.fixedWidth = 300f;
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Delete SPAwner")) {
                DeleteSpawner(SPO);
                Debug.Log("Deleted SPAwner");
            }
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUI.skin.button.fixedWidth = rememberWidth;
            EditorGUI.indentLevel--;
        }
    }

    //Create Spawner
    public Spawner CreateSpawner() {
        GameObject SPA = (GameObject)AssetDatabase.LoadAssetAtPath("Assets/The SPA/GameObjects/SpawnObject.prefab", typeof(GameObject));
        SPA = Instantiate(SPA, Vector3.zero, Quaternion.identity);
        SPA.name = "SPAwner";
        SpawnerList.Add(new SpawnObject(SPA.GetComponent<Spawner>()));
        FoldList.Add(true);

        return SPA.GetComponent<Spawner>();
    }

    //Delete Spawner
    void DeleteSpawner(SpawnObject SPO) {
        //Delete Spawner in Hierarchy
        GameObject[] SPOList = GameObject.FindGameObjectsWithTag("SPO");
        foreach(GameObject k in SPOList) {
            Spawner SP = k.GetComponent<Spawner>();
            if (SP.Equals(SPO.SP)) {
                DestroyImmediate(k);
            }
        }

        //Delete Spawner in Tool
        for(int i = 0; i < SpawnerList.Count; i++) {
            if (SPO.Equals(SpawnerList[i])) {
                SpawnerList.Remove(SpawnerList[i]);
                FoldList.Remove(FoldList[i]);
                break;
            }
        }   
    }

    //Get Spawners in Hierarchy
    void GetSpawnersInHierarchy() {
        //Get all Spawners in the Hierarchy
        GameObject[] SPOList = GameObject.FindGameObjectsWithTag("SPO");

        foreach (GameObject GO in SPOList) {
            Spawner SP = GO.GetComponent<Spawner>();
            if (SpawnerFoundInList(SP)) {
                continue;
            } 
            else {
                SpawnerList.Add(new SpawnObject(SP));
                FoldList.Add(false);
            }
        }
        
    }

    //Search for the same Spawner in SpawnList
    bool SpawnerFoundInList(Spawner SP) {
        foreach (SpawnObject SPO in SpawnerList) {
            if (SPO.SP == SP) {
                return true;
            }
        }

        return false;
    }

    //Set the GUIskins
    void SetGUIskin() {
        //Load Skin from Assets
        SPA_SKIN = (GUISkin)AssetDatabase.LoadAssetAtPath("Assets/The SPA/Assets/SPAskin.guiskin", typeof(GUISkin));
        GUI.skin = SPA_SKIN;
    }

    //Set Header Icon
    void SetTex() {
        tex = (Texture)AssetDatabase.LoadAssetAtPath("Assets/The SPA/Recources/Icon.png", typeof(Texture));
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUILayout.Label(tex, GUILayout.Height(70f), GUILayout.Width(70f));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
    }

    //Delete null pointer spawners
    void ClearNullSpawners() {
        for (int i = 0; i < SpawnerList.Count; i++) {
            if(SpawnerList[i].SP == null) {
                SpawnerList.Remove(SpawnerList[i]);
                FoldList.Remove(FoldList[i]);
            }
        }
    }

}//CLASS

