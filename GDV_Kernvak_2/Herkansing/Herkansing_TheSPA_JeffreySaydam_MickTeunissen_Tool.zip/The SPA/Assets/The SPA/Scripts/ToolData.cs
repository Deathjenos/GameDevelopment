﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ToolData {

    public float SpawnTime;
    public bool HasStartAmount;
    public int StartAmount;
    public bool HasRandomRotation;
    public bool RandomX;
    public float maximumRotationDegreeX;
    public bool RandomY;
    public float maximumRotationDegreeY;
    public bool RandomZ;
    public float maximumRotationDegreeZ;
    public bool HasSpawnArea;
    public bool MaximumObject;
    public int MaxObjectsAllowed;

    public ToolData (Spawner spawner) {
        //List that connects the spawner variables with the data variables
        SpawnTime = spawner.SpawnTime;
        HasStartAmount = spawner.HasStartAmount;
        StartAmount = spawner.StartAmount;
        HasRandomRotation = spawner.HasRandomRotation;
        RandomX = spawner.RandomX;
        maximumRotationDegreeX = spawner.maximumRotationDegreeX;
        RandomY = spawner.RandomY;
        maximumRotationDegreeY = spawner.maximumRotationDegreeY;
        RandomZ = spawner.RandomZ;
        maximumRotationDegreeZ = spawner.maximumRotationDegreeZ;
        HasSpawnArea = spawner.HasSpawnArea;
        MaximumObject = spawner.MaximumObject;
        MaxObjectsAllowed = spawner.MaxObjectsAllowed;
        
    }
}
