﻿using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class SaveToolData {

    //Saves preset with data to an external file
    public static void SaveToolPreset (Spawner spawner) {

        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + "PresetData.SPA";
        FileStream stream = new FileStream(path, FileMode.Create);

        ToolData data = new ToolData(spawner);

        formatter.Serialize(stream, data);
        stream.Close();

    }

    //Loads the preset that is saved (if it is saved)
    public static ToolData LoadToolPreset() {

        string path = Application.persistentDataPath + "PresetData.SPA";
        if (File.Exists(path)) {

            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);


            ToolData data = formatter.Deserialize(stream) as ToolData;
            stream.Close();

            //return the data if the file is found
            return data;

        } else {
            //if nothing is dave or no file is found
            Debug.LogError("SaveData file not found in " + path);
            return null;
        }

    }

}
